package homework;

public interface IElectronicDevice {

	void start();
	void stop();
	boolean isStarted();
	
}
